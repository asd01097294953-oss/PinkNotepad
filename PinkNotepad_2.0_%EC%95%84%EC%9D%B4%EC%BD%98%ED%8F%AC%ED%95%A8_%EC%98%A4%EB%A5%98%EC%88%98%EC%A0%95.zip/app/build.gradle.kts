plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.pinknotepad"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.pinknotepad"
        minSdk = 23
        targetSdk = 35
        versionCode = 2
        versionName = "2.0"
    }
}
