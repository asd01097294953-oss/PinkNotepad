package com.example.pinknotepad

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context

class MainActivity : Activity() {
    private val pink = Color.rgb(252, 228, 236)
    private val prefs by lazy { getSharedPreferences("notepad", MODE_PRIVATE) }
    private lateinit var editor: EditText
    private var noteColor = Color.BLACK
    private var noteSize = 18f
    private var updating = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        noteColor = prefs.getInt("textColor", Color.BLACK)
        noteSize = prefs.getFloat("textSize", 18f)

        window.statusBarColor = pink
        window.navigationBarColor = pink
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(pink)
        }

        val toolbarScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            setBackgroundColor(Color.rgb(255, 213, 225))
        }
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(5), dp(6), dp(5))
        }
        toolbar.addView(toolButton("A−") { changeFont(-2f) })
        toolbar.addView(toolButton("A+") { changeFont(2f) })
        toolbar.addView(toolButton("색상") { showColorPicker() })
        toolbar.addView(toolButton("복사") { copyAll() })
        toolbar.addView(toolButton("이모지") { showEmojiPicker() })
        toolbar.addView(toolButton("전체 삭제") { confirmClear() })
        toolbarScroll.addView(toolbar)
        root.addView(toolbarScroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))

        editor = EditText(this).apply {
            setText(prefs.getString("note", "") ?: "")
            setTextColor(noteColor)
            setHintTextColor(Color.GRAY)
            textSize = noteSize
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            gravity = Gravity.TOP or Gravity.START
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = null
            hint = "여기에 메모를 입력하세요"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            isSingleLine = false
            setHorizontallyScrolling(false)
            imeOptions = android.view.inputmethod.EditorInfo.IME_FLAG_NO_EXTRACT_UI
        }
        editor.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (!updating) prefs.edit().putString("note", s?.toString() ?: "").apply()
            }
            override fun afterTextChanged(s: Editable?) {}
        })
        root.addView(editor, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        setContentView(root)
    }

    private fun toolButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 13f
            isAllCaps = false
            setTextColor(Color.rgb(75, 40, 52))
            backgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(255, 241, 245))
            setPadding(dp(10), 0, dp(10), 0)
            minWidth = dp(48)
            minHeight = dp(42)
            setOnClickListener { action() }
            val lp = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(42)
            )
            lp.setMargins(dp(3), 0, dp(3), 0)
            layoutParams = lp
        }

    private fun changeFont(delta: Float) {
        noteSize = (noteSize + delta).coerceIn(12f, 36f)
        editor.textSize = noteSize
        prefs.edit().putFloat("textSize", noteSize).apply()
    }

    private fun showColorPicker() {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(4))
        }
        val preview = TextView(this).apply {
            text = "글씨 색상 미리보기"
            textSize = 18f
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(10))
        }
        panel.addView(preview)
        val bars = mutableListOf<SeekBar>()
        val values = intArrayOf(Color.red(noteColor), Color.green(noteColor), Color.blue(noteColor))
        val labels = listOf("빨강", "초록", "파랑")
        for (i in 0..2) {
            panel.addView(TextView(this).apply { text = labels[i] })
            val bar = SeekBar(this).apply { max = 255; progress = values[i] }
            bars.add(bar)
            panel.addView(bar)
        }
        fun updatePreview() {
            val c = Color.rgb(bars[0].progress, bars[1].progress, bars[2].progress)
            preview.setTextColor(c)
        }
        bars.forEach { it.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) = updatePreview()
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        }) }
        updatePreview()
        AlertDialog.Builder(this)
            .setTitle("글씨 색상 선택")
            .setView(panel)
            .setNegativeButton("취소", null)
            .setPositiveButton("적용") { _, _ ->
                noteColor = Color.rgb(bars[0].progress, bars[1].progress, bars[2].progress)
                editor.setTextColor(noteColor)
                prefs.edit().putInt("textColor", noteColor).apply()
            }.show()
    }

    private fun copyAll() {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("메모", editor.text.toString()))
        AlertDialog.Builder(this).setMessage("메모 전체를 복사했어요.")
            .setPositiveButton("확인", null).show()
    }

    private fun showEmojiPicker() {
        val emojis = arrayOf("😀", "😂", "🥰", "😍", "😊", "😭", "😎", "👍", "❤️", "💕",
            "🌸", "🌷", "🌈", "⭐", "✨", "🎀", "🐱", "🐰", "🍀", "☁️")
        AlertDialog.Builder(this).setTitle("이모지 넣기")
            .setItems(emojis) { _, which ->
                val start = editor.selectionStart.coerceAtLeast(0)
                editor.text.insert(start, emojis[which])
            }.setNegativeButton("닫기", null).show()
    }

    private fun confirmClear() {
        AlertDialog.Builder(this)
            .setTitle("전체 삭제")
            .setMessage("메모 내용을 모두 삭제할까요?")
            .setNegativeButton("취소", null)
            .setPositiveButton("삭제") { _, _ -> editor.text.clear() }
            .show()
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density + 0.5f).toInt()
}
