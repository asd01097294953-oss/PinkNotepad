핑크 메모장 2.0

추가된 기능
- 화면 맨 위에 가로 도구 바
- 글씨 크기 A− / A+ (12~36)
- 빨강/초록/파랑 값을 조절하는 글씨 색상 선택
- 메모 전체 복사
- 이모지 삽입
- 전체 삭제 확인 창
- 메모, 글씨 크기, 글씨 색상 자동 저장

기존 앱과 같은 applicationId(com.example.pinknotepad)와 메모 저장 이름(notepad)을 사용합니다.
APK 빌드: GitHub 저장소에 올린 뒤 Actions에서 Build PinkNotepad APK 실행
완성 APK: Actions 실행 결과의 Artifacts에서 PinkNotepad-2.0-APK 다운로드

앱 아이콘: 사용자가 제공한 캐릭터 이미지를 런처 아이콘으로 적용했습니다.
