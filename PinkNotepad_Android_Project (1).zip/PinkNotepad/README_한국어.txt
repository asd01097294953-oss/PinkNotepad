핑크 메모장 - Android Studio 프로젝트

디자인
- 배경: 연한 핑크 (#FCE4EC)
- 글씨: 검정색
- 메뉴/카드/광고 없이 빈 편집 화면
- 입력 내용은 휴대폰 내부에 자동 저장됩니다.
- 인터넷 권한이나 외부 라이브러리를 사용하지 않습니다.

APK 만들기
1. Android Studio를 설치합니다.
2. Android Studio에서 이 폴더(PinkNotepad)를 엽니다.
3. Gradle 동기화가 끝날 때까지 기다립니다.
4. 메뉴에서 Build > Build Bundle(s) / APK(s) > Build APK(s)를 선택합니다.
5. 생성된 APK는 app/build/outputs/apk/debug/app-debug.apk 에 있습니다.

참고
- 이 압축파일은 APK 자체가 아니라 Android Studio 프로젝트입니다.
- compileSdk 35 및 Android Gradle Plugin 8.7.3을 사용합니다.
- 첫 Gradle 동기화에는 인터넷 연결이 필요할 수 있습니다.
- 앱 실행 후 입력한 내용은 자동 저장됩니다.
