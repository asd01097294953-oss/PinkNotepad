package com.example.pinknotepad

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.text.InputType
import android.text.TextWatcher
import android.text.Editable
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout

class MainActivity : Activity() {
    private val pink = Color.rgb(252, 228, 236)
    private val prefs by lazy { getSharedPreferences("notepad", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = pink
        window.navigationBarColor = pink
        window.decorView.systemUiVisibility =
            android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
            android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)

        val editor = EditText(this).apply {
            setText(prefs.getString("note", "") ?: "")
            setTextColor(Color.BLACK)
            setHintTextColor(Color.BLACK)
            textSize = 18f
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            gravity = Gravity.TOP or Gravity.START
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = null
            hint = ""
            inputType = InputType.TYPE_CLASS_TEXT or
                InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            isSingleLine = false
            setHorizontallyScrolling(false)
            imeOptions = android.view.inputmethod.EditorInfo.IME_FLAG_NO_EXTRACT_UI
        }

        editor.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                prefs.edit().putString("note", s?.toString() ?: "").apply()
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        val root = FrameLayout(this).apply {
            setBackgroundColor(pink)
            addView(editor, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            ))
        }
        setContentView(root)
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density + 0.5f).toInt()
}
